import { ActorModel } from '@/models/actor';
import { SerieModel } from '@/models/serie';

export class StorageService {
    private static readonly ACTORS_KEY = 'actors';
    private static readonly SERIES_KEY = 'series';

    // ACTOR METHODS

    /**
     * Save an actor to localStorage and update related series
     */
    public static saveActor(actor: ActorModel): void {
        const actors = this.getAllActors();
        const existingActor = actors.find((a) => a.code === actor.code);
        const isNew = !existingActor;

        // If updating an existing actor, we need to handle removed series relationships
        if (!isNew && existingActor) {
            // Find series that were removed from the actor
            const removedSeries = existingActor.series.filter(
                (serieCode) => !actor.series.includes(serieCode)
            );

            // Remove actor from those series
            removedSeries.forEach((serieCode) => {
                const serie = this.getSerieByCode(serieCode);
                if (serie) {
                    serie.actors = serie.actors.filter(
                        (actorCode) => actorCode !== actor.code
                    );
                    this._saveSerieWithoutActorUpdate(serie);
                }
            });
        }

        // Add actor to series that don't already include it
        actor.series.forEach((serieCode) => {
            const serie = this.getSerieByCode(serieCode);
            if (serie && !serie.actors.includes(actor.code)) {
                serie.actors.push(actor.code);
                this._saveSerieWithoutActorUpdate(serie);
            }
        });

        // Save the actor itself
        const actorIndex = actors.findIndex((a) => a.code === actor.code);
        if (actorIndex >= 0) {
            actors[actorIndex] = actor;
        } else {
            actors.push(actor);
        }

        localStorage.setItem(this.ACTORS_KEY, JSON.stringify(actors));
    }

    /**
     * Get all actors from localStorage
     */
    public static getAllActors(): ActorModel[] {
        const actorsJson = localStorage.getItem(this.ACTORS_KEY);
        if (!actorsJson) {
            return [];
        }

        const actorsData = JSON.parse(actorsJson);
        return actorsData.map(ActorModel.fromJSON);
    }

    /**
     * Get an actor by code
     */
    public static getActorByCode(code: string): ActorModel | null {
        const actors = this.getAllActors();
        const actor = actors.find((a) => a.code === code);
        return actor || null;
    }

    /**
     * Update an existing actor
     */
    public static updateActor(actor: ActorModel): boolean {
        const actors = this.getAllActors();
        const index = actors.findIndex((a) => a.code === actor.code);

        if (index === -1) {
            return false;
        }

        // Use saveActor to handle series relationships
        this.saveActor(actor);
        return true;
    }

    /**
     * Delete an actor by code
     */
    public static deleteActor(code: string): boolean {
        const actors = this.getAllActors();
        const actor = actors.find((a) => a.code === code);

        if (!actor) {
            return false;
        }

        // Remove actor from all series it was in
        actor.series.forEach((serieCode) => {
            const serie = this.getSerieByCode(serieCode);
            if (serie) {
                serie.actors = serie.actors.filter(
                    (actorCode) => actorCode !== code
                );
                this._saveSerieWithoutActorUpdate(serie);
            }
        });

        // Remove actor from the list
        const filteredActors = actors.filter((a) => a.code !== code);
        localStorage.setItem(this.ACTORS_KEY, JSON.stringify(filteredActors));

        return true;
    }

    // SERIE METHODS

    /**
     * Save a serie to localStorage and update related actors
     */
    public static saveSerie(serie: SerieModel): void {
        const series = this.getAllSeries();
        const existingSerie = series.find((s) => s.code === serie.code);
        const isNew = !existingSerie;

        // If updating an existing serie, we need to handle removed actor relationships
        if (!isNew && existingSerie) {
            // Find actors that were removed from the serie
            const removedActors = existingSerie.actors.filter(
                (actorCode) => !serie.actors.includes(actorCode)
            );

            // Remove serie from those actors
            removedActors.forEach((actorCode) => {
                const actor = this.getActorByCode(actorCode);
                if (actor) {
                    actor.series = actor.series.filter(
                        (serieCode) => serieCode !== serie.code
                    );
                    this._saveActorWithoutSerieUpdate(actor);
                }
            });
        }

        // Add serie to actors that don't already include it
        serie.actors.forEach((actorCode) => {
            const actor = this.getActorByCode(actorCode);
            if (actor && !actor.series.includes(serie.code)) {
                actor.series.push(serie.code);
                this._saveActorWithoutSerieUpdate(actor);
            }
        });

        // Save the serie itself
        const serieIndex = series.findIndex((s) => s.code === serie.code);
        if (serieIndex >= 0) {
            series[serieIndex] = serie;
        } else {
            series.push(serie);
        }

        localStorage.setItem(this.SERIES_KEY, JSON.stringify(series));
    }

    /**
     * Get all series from localStorage
     */
    public static getAllSeries(): SerieModel[] {
        const seriesJson = localStorage.getItem(this.SERIES_KEY);
        if (!seriesJson) {
            return [];
        }

        const seriesData = JSON.parse(seriesJson);
        return seriesData.map(SerieModel.fromJSON);
    }

    /**
     * Get a serie by code
     */
    public static getSerieByCode(code: string): SerieModel | null {
        const series = this.getAllSeries();
        const serie = series.find((s) => s.code === code);
        return serie || null;
    }

    /**
     * Update an existing serie
     */
    public static updateSerie(serie: SerieModel): boolean {
        const series = this.getAllSeries();
        const index = series.findIndex((s) => s.code === serie.code);

        if (index === -1) {
            return false;
        }

        // Use saveSerie to handle actor relationships
        this.saveSerie(serie);
        return true;
    }

    /**
     * Delete a serie by code
     */
    public static deleteSerie(code: string): boolean {
        const series = this.getAllSeries();
        const serie = series.find((s) => s.code === code);

        if (!serie) {
            return false;
        }

        // Remove serie from all actors it contained
        serie.actors.forEach((actorCode) => {
            const actor = this.getActorByCode(actorCode);
            if (actor) {
                actor.series = actor.series.filter(
                    (serieCode) => serieCode !== code
                );
                this._saveActorWithoutSerieUpdate(actor);
            }
        });

        // Remove serie from the list
        const filteredSeries = series.filter((s) => s.code !== code);
        localStorage.setItem(this.SERIES_KEY, JSON.stringify(filteredSeries));

        return true;
    }

    // UTILITY METHODS

    /**
     * Clear all data from localStorage
     */
    public static clearAll(): void {
        localStorage.removeItem(this.ACTORS_KEY);
        localStorage.removeItem(this.SERIES_KEY);
    }

    /**
     * Get series by actor code
     */
    public static getSeriesByActorCode(actorCode: string): SerieModel[] {
        return this.getAllSeries().filter((serie) =>
            serie.actors.includes(actorCode)
        );
    }

    /**
     * Get actors by serie code
     */
    public static getActorsBySerieCode(serieCode: string): ActorModel[] {
        return this.getAllActors().filter((actor) =>
            actor.series.includes(serieCode)
        );
    }

    // PRIVATE HELPER METHODS

    /**
     * Save actor without updating series references
     * Used internally to avoid infinite recursion
     */
    private static _saveActorWithoutSerieUpdate(actor: ActorModel): void {
        const actors = this.getAllActors();
        const actorIndex = actors.findIndex((a) => a.code === actor.code);

        if (actorIndex >= 0) {
            actors[actorIndex] = actor;
        } else {
            actors.push(actor);
        }

        localStorage.setItem(this.ACTORS_KEY, JSON.stringify(actors));
    }

    /**
     * Save serie without updating actor references
     * Used internally to avoid infinite recursion
     */
    private static _saveSerieWithoutActorUpdate(serie: SerieModel): void {
        const series = this.getAllSeries();
        const serieIndex = series.findIndex((s) => s.code === serie.code);

        if (serieIndex >= 0) {
            series[serieIndex] = serie;
        } else {
            series.push(serie);
        }

        localStorage.setItem(this.SERIES_KEY, JSON.stringify(series));
    }
}
